package com.jts.tdd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TddApproachDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
