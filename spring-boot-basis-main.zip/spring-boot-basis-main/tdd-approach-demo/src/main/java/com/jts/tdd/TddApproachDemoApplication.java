package com.jts.tdd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TddApproachDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TddApproachDemoApplication.class, args);
	}

}
