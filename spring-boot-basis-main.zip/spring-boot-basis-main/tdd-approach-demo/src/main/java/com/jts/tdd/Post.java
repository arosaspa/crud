package com.jts.tdd;

public record Post(int id, int userId, String title, String body) {

}
