package com.jts;

public record Products(int id, String name, int price) {

}
