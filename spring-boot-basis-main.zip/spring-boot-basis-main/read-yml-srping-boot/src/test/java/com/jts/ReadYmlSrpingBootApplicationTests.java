package com.jts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReadYmlSrpingBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
