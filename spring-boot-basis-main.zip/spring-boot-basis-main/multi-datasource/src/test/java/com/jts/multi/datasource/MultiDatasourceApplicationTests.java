package com.jts.multi.datasource;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiDatasourceApplicationTests {

	@Test
	void contextLoads() {
	}

}
