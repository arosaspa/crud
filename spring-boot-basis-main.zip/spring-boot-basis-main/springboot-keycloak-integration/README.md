# Spring Boot v3 Keycloak Integration

Demo project for integrating Keycloak with Spring Boot 3

Endpoints

<br>
Admin:
<br>
[GET] http://localhost:8081/api/admin <br>
Authorization - Bearer Token with admin privileges
<br>
<br>
User:
<br>
[GET] http://localhost:8081/api/user <br>
Authorization - Bearer Token with user privileges

<br>

