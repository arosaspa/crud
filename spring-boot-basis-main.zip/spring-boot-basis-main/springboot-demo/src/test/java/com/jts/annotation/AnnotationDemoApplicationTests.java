package com.jts.annotation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnnotationDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
