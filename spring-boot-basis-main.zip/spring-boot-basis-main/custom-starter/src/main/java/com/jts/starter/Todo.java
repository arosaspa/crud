package com.jts.starter;

public record Todo(Integer userId, Integer id, String title, Boolean completed) {

}
